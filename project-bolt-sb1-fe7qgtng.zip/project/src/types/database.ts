export interface Customer {
  customer_id: number;
  name: string;
  email: string;
  age: number;
  city: string;
  country: string;
  registration_date: string;
  total_purchases: number;
  last_purchase_date: string | null;
  loyalty_level: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
}

export interface QueryResult {
  sqlQuery: string;
  data: any[];
  columns: string[];
  error?: string;
}

export interface QueryHistoryItem {
  id: string;
  naturalLanguage: string;
  sqlQuery: string;
  timestamp: Date;
  resultCount: number;
}
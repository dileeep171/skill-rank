import React from 'react';
import { Lightbulb, Users, TrendingUp, MapPin, Award, Clock } from 'lucide-react';

interface SampleQueriesProps {
  onQuerySelect: (query: string) => void;
}

const SampleQueries: React.FC<SampleQueriesProps> = ({ onQuerySelect }) => {
  const sampleQueries = [
    {
      category: 'Customer Overview',
      icon: Users,
      queries: [
        'Show me all customers',
        'Count all customers',
        'Find customers from USA',
        'Show customers from Europe'
      ]
    },
    {
      category: 'Loyalty & Value',
      icon: Award,
      queries: [
        'Show gold customers',
        'Find platinum customers',
        'Show customers with high purchases',
        'Top 5 customers by purchases'
      ]
    },
    {
      category: 'Demographics',
      icon: TrendingUp,
      queries: [
        'Find customers older than 30',
        'Show customers younger than 25',
        'Average age of customers',
        'Customers in their 30s'
      ]
    },
    {
      category: 'Recent Activity',
      icon: Clock,
      queries: [
        'Customers who purchased recently',
        'Customers who haven\'t purchased recently',
        'Recent purchases this month',
        'Inactive customers'
      ]
    }
  ];

  return (
    <div className="mt-6">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center mb-4">
          <Lightbulb className="w-5 h-5 text-yellow-500 mr-2" />
          <h3 className="text-lg font-semibold text-gray-900">Sample Queries</h3>
        </div>
        <p className="text-sm text-gray-600 mb-6">
          Try these example queries to explore your customer data
        </p>
        
        <div className="space-y-6">
          {sampleQueries.map((category, categoryIndex) => (
            <div key={categoryIndex}>
              <div className="flex items-center mb-3">
                <category.icon className="w-4 h-4 text-blue-600 mr-2" />
                <h4 className="text-sm font-medium text-gray-800">{category.category}</h4>
              </div>
              <div className="space-y-2">
                {category.queries.map((query, queryIndex) => (
                  <button
                    key={queryIndex}
                    onClick={() => onQuerySelect(query)}
                    className="w-full text-left p-3 text-sm text-gray-700 bg-gray-50 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors border border-transparent hover:border-blue-200 group"
                  >
                    <span className="group-hover:font-medium">"{query}"</span>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start">
            <div className="flex-shrink-0">
              <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">?</span>
              </div>
            </div>
            <div className="ml-3">
              <h4 className="text-sm font-medium text-blue-900 mb-1">Pro Tip</h4>
              <p className="text-sm text-blue-800">
                You can use natural language! Try queries like "Find customers from New York with more than $1000 in purchases" 
                or "Show me young platinum customers."
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SampleQueries;
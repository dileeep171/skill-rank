import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Users, 
  DollarSign, 
  TrendingUp, 
  Globe,
  Award,
  Calendar,
  Activity
} from 'lucide-react';
import { getDatabaseStats } from '../services/database';

const DatabaseStats: React.FC = () => {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      setLoading(true);
      try {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 500));
        const data = getDatabaseStats();
        setStats(data);
      } catch (error) {
        console.error('Failed to load stats:', error);
      } finally {
        setLoading(false);
      }
    };

    loadStats();
  }, []);

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <div className="flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading database statistics...</span>
        </div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
        <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">Unable to Load Statistics</h3>
        <p className="text-gray-500">Please try again later.</p>
      </div>
    );
  }

  const StatCard: React.FC<{
    icon: React.ComponentType<any>;
    title: string;
    value: string | number;
    change?: string;
    changeType?: 'positive' | 'negative' | 'neutral';
    subtitle?: string;
  }> = ({ icon: Icon, title, value, change, changeType = 'neutral', subtitle }) => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center">
        <div className="flex-shrink-0">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
            <Icon className="w-5 h-5 text-blue-600" />
          </div>
        </div>
        <div className="ml-4 flex-1">
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
          {subtitle && (
            <p className="text-sm text-gray-500">{subtitle}</p>
          )}
          {change && (
            <p className={`text-sm font-medium ${
              changeType === 'positive' ? 'text-green-600' : 
              changeType === 'negative' ? 'text-red-600' : 'text-gray-600'
            }`}>
              {change}
            </p>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          icon={Users}
          title="Total Customers"
          value={stats.totalCustomers.toLocaleString()}
          change="+12% from last month"
          changeType="positive"
        />
        <StatCard
          icon={DollarSign}
          title="Total Revenue"
          value={`$${stats.totalRevenue.toLocaleString()}`}
          change="+8% from last month"
          changeType="positive"
        />
        <StatCard
          icon={TrendingUp}
          title="Average Age"
          value={`${stats.averageAge} years`}
          subtitle="Customer demographics"
        />
        <StatCard
          icon={Activity}
          title="Recent Purchases"
          value={stats.recentPurchases}
          subtitle="This month"
          change="+15% vs last month"
          changeType="positive"
        />
      </div>

      {/* Detailed Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Loyalty Distribution */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center mb-6">
            <Award className="w-5 h-5 text-purple-600 mr-2" />
            <h3 className="text-lg font-semibold text-gray-900">Loyalty Distribution</h3>
          </div>
          
          <div className="space-y-4">
            {Object.entries(stats.loyaltyDistribution).map(([level, count]) => {
              const percentage = Math.round((count as number / stats.totalCustomers) * 100);
              const colors = {
                Platinum: 'bg-purple-500',
                Gold: 'bg-yellow-500',
                Silver: 'bg-gray-400',
                Bronze: 'bg-orange-500'
              };
              
              return (
                <div key={level} className="flex items-center">
                  <div className="flex items-center min-w-0 flex-1">
                    <div className="flex-shrink-0 mr-3">
                      <div className={`w-3 h-3 rounded-full ${colors[level as keyof typeof colors]}`} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-gray-900 truncate">{level}</p>
                      <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                        <div 
                          className={`h-2 rounded-full ${colors[level as keyof typeof colors]}`}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="ml-4 flex-shrink-0 text-right">
                    <p className="text-sm font-medium text-gray-900">{count}</p>
                    <p className="text-xs text-gray-500">{percentage}%</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Country Distribution */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center mb-6">
            <Globe className="w-5 h-5 text-green-600 mr-2" />
            <h3 className="text-lg font-semibold text-gray-900">Geographic Distribution</h3>
          </div>
          
          <div className="space-y-3">
            {Object.entries(stats.countryDistribution)
              .sort((a, b) => (b[1] as number) - (a[1] as number))
              .map(([country, count]) => {
                const percentage = Math.round((count as number / stats.totalCustomers) * 100);
                
                return (
                  <div key={country} className="flex items-center justify-between">
                    <div className="flex items-center min-w-0 flex-1">
                      <span className="text-sm font-medium text-gray-900">{country}</span>
                      <div className="ml-3 flex-1 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                    <div className="ml-4 flex-shrink-0 text-right">
                      <span className="text-sm font-medium text-gray-900">{count}</span>
                      <span className="text-xs text-gray-500 ml-1">({percentage}%)</span>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </div>

      {/* Database Schema Info */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center mb-6">
          <BarChart3 className="w-5 h-5 text-blue-600 mr-2" />
          <h3 className="text-lg font-semibold text-gray-900">Database Schema</h3>
        </div>
        
        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="text-sm font-medium text-gray-900 mb-3">Customers Table Structure</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 text-xs">
            {[
              'customer_id (Primary Key)',
              'name (Text)',
              'email (Email)',
              'age (Number)',
              'city (Text)',
              'country (Text)',
              'registration_date (Date)',
              'total_purchases (Currency)',
              'last_purchase_date (Date)',
              'loyalty_level (Category)'
            ].map((field) => (
              <div key={field} className="bg-white p-2 rounded border">
                <code className="text-gray-700">{field}</code>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DatabaseStats;
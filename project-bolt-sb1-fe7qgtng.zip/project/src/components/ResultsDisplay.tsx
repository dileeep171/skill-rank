import React from 'react';
import { CheckCircle, AlertCircle, Database, Download, Copy } from 'lucide-react';
import { QueryResult } from '../types/database';

interface ResultsDisplayProps {
  results: QueryResult;
  loading: boolean;
  naturalLanguageQuery: string;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ 
  results, 
  loading, 
  naturalLanguageQuery 
}) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopySQL = async () => {
    try {
      await navigator.clipboard.writeText(results.sqlQuery);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy SQL:', err);
    }
  };

  const handleExportCSV = () => {
    if (results.data.length === 0) return;
    
    const csv = [
      results.columns.join(','),
      ...results.data.map(row => 
        results.columns.map(col => {
          const value = row[col];
          return typeof value === 'string' && value.includes(',') 
            ? `"${value}"` 
            : String(value || '');
        }).join(',')
      )
    ].join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'query_results.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const formatValue = (value: any): string => {
    if (value === null || value === undefined) return 'N/A';
    if (typeof value === 'number') {
      return value.toLocaleString();
    }
    if (typeof value === 'string' && value.match(/^\d{4}-\d{2}-\d{2}/)) {
      return new Date(value).toLocaleDateString();
    }
    return String(value);
  };

  const getColumnType = (column: string, data: any[]): string => {
    if (data.length === 0) return 'text';
    const sampleValue = data[0][column];
    if (typeof sampleValue === 'number') return 'number';
    if (typeof sampleValue === 'string' && sampleValue.match(/^\d{4}-\d{2}-\d{2}/)) return 'date';
    return 'text';
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <div className="flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Processing your query...</span>
        </div>
      </div>
    );
  }

  if (results.error) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-red-200 p-6">
        <div className="flex items-start">
          <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-red-800">Query Error</h3>
            <p className="mt-1 text-sm text-red-700">{results.error}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Query Summary */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-start justify-between">
          <div className="flex items-start">
            <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
            <div className="ml-3">
              <h3 className="text-sm font-medium text-gray-900">Query Executed Successfully</h3>
              <p className="mt-1 text-sm text-gray-600">
                Found <span className="font-semibold text-blue-600">{results.data.length}</span> results
                {naturalLanguageQuery && (
                  <span className="text-gray-500"> for "{naturalLanguageQuery}"</span>
                )}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopySQL}
              className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
            >
              <Copy className="w-3 h-3 mr-1" />
              {copied ? 'Copied!' : 'Copy SQL'}
            </button>
            {results.data.length > 0 && (
              <button
                onClick={handleExportCSV}
                className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
              >
                <Download className="w-3 h-3 mr-1" />
                Export CSV
              </button>
            )}
          </div>
        </div>
        
        {/* Generated SQL */}
        {results.sqlQuery && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg border">
            <div className="flex items-center mb-2">
              <Database className="w-4 h-4 text-gray-500 mr-2" />
              <span className="text-sm font-medium text-gray-700">Generated SQL:</span>
            </div>
            <code className="text-sm text-gray-800 font-mono break-all">
              {results.sqlQuery}
            </code>
          </div>
        )}
      </div>

      {/* Results Table */}
      {results.data.length > 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  {results.columns.map((column, index) => (
                    <th
                      key={index}
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      <div className="flex items-center space-x-1">
                        <span>{column.replace(/_/g, ' ')}</span>
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                          {getColumnType(column, results.data)}
                        </span>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {results.data.map((row, rowIndex) => (
                  <tr 
                    key={rowIndex} 
                    className={rowIndex % 2 === 0 ? 'bg-white' : 'bg-gray-50'}
                  >
                    {results.columns.map((column, colIndex) => (
                      <td 
                        key={colIndex} 
                        className="px-6 py-4 whitespace-nowrap text-sm text-gray-900"
                      >
                        <div className="flex items-center">
                          {column === 'loyalty_level' && (
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium mr-2 ${
                              row[column] === 'Platinum' ? 'bg-purple-100 text-purple-800' :
                              row[column] === 'Gold' ? 'bg-yellow-100 text-yellow-800' :
                              row[column] === 'Silver' ? 'bg-gray-100 text-gray-800' :
                              'bg-orange-100 text-orange-800'
                            }`}>
                              {row[column]}
                            </span>
                          )}
                          {column === 'email' && (
                            <a 
                              href={`mailto:${row[column]}`} 
                              className="text-blue-600 hover:text-blue-900 hover:underline"
                            >
                              {formatValue(row[column])}
                            </a>
                          )}
                          {column !== 'loyalty_level' && column !== 'email' && (
                            <span className={
                              column.includes('total_purchases') || column.includes('revenue') || column.includes('amount') 
                                ? 'font-mono font-semibold text-green-600' 
                                : ''
                            }>
                              {formatValue(row[column])}
                            </span>
                          )}
                        </div>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <Database className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Results Found</h3>
          <p className="text-gray-500">
            Your query executed successfully but didn't return any data. 
            Try adjusting your search criteria.
          </p>
        </div>
      )}
    </div>
  );
};

export default ResultsDisplay;
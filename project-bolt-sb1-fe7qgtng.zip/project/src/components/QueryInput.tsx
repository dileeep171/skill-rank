import React, { useState, useRef } from 'react';
import { Send, Loader2, Sparkles } from 'lucide-react';

interface QueryInputProps {
  onSubmit: (query: string) => void;
  loading: boolean;
  currentQuery: string;
}

const QueryInput: React.FC<QueryInputProps> = ({ onSubmit, loading, currentQuery }) => {
  const [query, setQuery] = useState(currentQuery);
  const [isFocused, setIsFocused] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim() && !loading) {
      onSubmit(query.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const suggestions = [
    "Show me all customers",
    "Find customers from USA", 
    "Show gold customers",
    "Find customers older than 30",
    "Top 5 customers by purchases",
    "Count all customers"
  ];

  // Update internal state when currentQuery prop changes
  React.useEffect(() => {
    if (currentQuery !== query) {
      setQuery(currentQuery);
    }
  }, [currentQuery]);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <form onSubmit={handleSubmit} className="relative">
        <div className="flex items-start p-4">
          <div className="flex-shrink-0 mr-3 mt-1">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <textarea
              ref={textareaRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              placeholder="Ask me anything about your customers... (e.g., 'Show me all gold customers from USA')"
              className="w-full resize-none border-0 bg-transparent text-gray-900 placeholder-gray-500 focus:outline-none text-lg leading-6"
              rows={isFocused || query.length > 50 ? 3 : 1}
              disabled={loading}
            />
          </div>
          <button
            type="submit"
            disabled={!query.trim() || loading}
            className="flex-shrink-0 ml-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
            <span className="ml-2 hidden sm:inline">
              {loading ? 'Analyzing...' : 'Ask'}
            </span>
          </button>
        </div>
        
        {isFocused && !query && (
          <div className="border-t border-gray-100 p-4 bg-gray-50">
            <p className="text-sm text-gray-600 mb-3 font-medium">Try asking:</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => {
                    setQuery(suggestion);
                    textareaRef.current?.focus();
                  }}
                  className="text-left text-sm text-gray-700 hover:text-blue-600 hover:bg-white p-2 rounded-lg transition-colors border border-transparent hover:border-blue-200"
                >
                  "{suggestion}"
                </button>
              ))}
            </div>
          </div>
        )}
      </form>
    </div>
  );
};

export default QueryInput;
import React from 'react';
import { History, Play, Trash2, Clock, Database } from 'lucide-react';
import { QueryHistoryItem } from '../types/database';

interface QueryHistoryProps {
  history: QueryHistoryItem[];
  onQuerySelect: (item: QueryHistoryItem) => void;
}

const QueryHistory: React.FC<QueryHistoryProps> = ({ history, onQuerySelect }) => {
  const formatTimeAgo = (timestamp: Date): string => {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - timestamp.getTime()) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return `${Math.floor(diffInSeconds / 86400)}d ago`;
  };

  if (history.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
        <History className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No Query History</h3>
        <p className="text-gray-500">
          Your executed queries will appear here for easy access and re-running.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center">
          <History className="w-5 h-5 text-gray-500 mr-2" />
          <h2 className="text-lg font-semibold text-gray-900">Query History</h2>
          <span className="ml-3 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            {history.length} {history.length === 1 ? 'query' : 'queries'}
          </span>
        </div>
        <p className="mt-1 text-sm text-gray-600">
          Click on any query to run it again or view its results.
        </p>
      </div>

      <div className="divide-y divide-gray-200">
        {history.map((item) => (
          <div
            key={item.id}
            className="p-6 hover:bg-gray-50 transition-colors group"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-3 mb-2">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Database className="w-4 h-4 text-blue-600" />
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {item.naturalLanguage}
                    </p>
                    <div className="flex items-center mt-1 text-xs text-gray-500 space-x-4">
                      <div className="flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {formatTimeAgo(item.timestamp)}
                      </div>
                      <span>•</span>
                      <span className="font-medium text-green-600">
                        {item.resultCount} results
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="mt-3 p-3 bg-gray-100 rounded-lg">
                  <code className="text-xs text-gray-700 font-mono break-all">
                    {item.sqlQuery}
                  </code>
                </div>
              </div>
              
              <div className="ml-4 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => onQuerySelect(item)}
                  className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
                >
                  <Play className="w-4 h-4 mr-1.5" />
                  Run Again
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QueryHistory;
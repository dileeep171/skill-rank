// In-memory database simulation with sample data
export interface Customer {
  customer_id: number;
  name: string;
  email: string;
  age: number;
  city: string;
  country: string;
  registration_date: string;
  total_purchases: number;
  last_purchase_date: string | null;
  loyalty_level: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
}

// Sample customer data
const customers: Customer[] = [
  {
    customer_id: 1,
    name: "Alice Johnson",
    email: "alice@example.com",
    age: 28,
    city: "New York",
    country: "USA",
    registration_date: "2023-01-15",
    total_purchases: 1250.75,
    last_purchase_date: "2024-01-10",
    loyalty_level: "Gold"
  },
  {
    customer_id: 2,
    name: "Bob Smith",
    email: "bob@example.com",
    age: 34,
    city: "London",
    country: "UK",
    registration_date: "2022-11-20",
    total_purchases: 890.50,
    last_purchase_date: "2024-01-08",
    loyalty_level: "Silver"
  },
  {
    customer_id: 3,
    name: "Carol Davis",
    email: "carol@example.com",
    age: 42,
    city: "Toronto",
    country: "Canada",
    registration_date: "2023-03-10",
    total_purchases: 2100.25,
    last_purchase_date: "2024-01-12",
    loyalty_level: "Platinum"
  },
  {
    customer_id: 4,
    name: "David Wilson",
    email: "david@example.com",
    age: 25,
    city: "Sydney",
    country: "Australia",
    registration_date: "2023-06-18",
    total_purchases: 450.00,
    last_purchase_date: "2024-01-05",
    loyalty_level: "Bronze"
  },
  {
    customer_id: 5,
    name: "Emma Brown",
    email: "emma@example.com",
    age: 31,
    city: "Berlin",
    country: "Germany",
    registration_date: "2022-08-22",
    total_purchases: 1680.90,
    last_purchase_date: "2024-01-11",
    loyalty_level: "Gold"
  },
  {
    customer_id: 6,
    name: "Frank Miller",
    email: "frank@example.com",
    age: 38,
    city: "Paris",
    country: "France",
    registration_date: "2023-02-14",
    total_purchases: 3200.45,
    last_purchase_date: "2024-01-09",
    loyalty_level: "Platinum"
  },
  {
    customer_id: 7,
    name: "Grace Lee",
    email: "grace@example.com",
    age: 29,
    city: "Tokyo",
    country: "Japan",
    registration_date: "2023-04-30",
    total_purchases: 975.30,
    last_purchase_date: "2024-01-07",
    loyalty_level: "Silver"
  },
  {
    customer_id: 8,
    name: "Henry Taylor",
    email: "henry@example.com",
    age: 45,
    city: "Mumbai",
    country: "India",
    registration_date: "2022-12-05",
    total_purchases: 1450.85,
    last_purchase_date: "2024-01-06",
    loyalty_level: "Gold"
  },
  {
    customer_id: 9,
    name: "Ivy Chen",
    email: "ivy@example.com",
    age: 26,
    city: "Singapore",
    country: "Singapore",
    registration_date: "2023-07-12",
    total_purchases: 680.20,
    last_purchase_date: "2024-01-04",
    loyalty_level: "Silver"
  },
  {
    customer_id: 10,
    name: "Jack Anderson",
    email: "jack@example.com",
    age: 35,
    city: "Los Angeles",
    country: "USA",
    registration_date: "2023-01-28",
    total_purchases: 2890.75,
    last_purchase_date: "2024-01-13",
    loyalty_level: "Platinum"
  }
];

// Simple SQL parser and executor
export class SQLExecutor {
  private data: Customer[] = customers;

  execute(sql: string): any[] {
    const normalizedSQL = sql.toLowerCase().trim();
    
    // Handle SELECT queries
    if (normalizedSQL.startsWith('select')) {
      return this.executeSelect(normalizedSQL);
    }
    
    throw new Error('Only SELECT queries are supported in this demo');
  }

  private executeSelect(sql: string): any[] {
    let results = [...this.data];
    
    // Parse WHERE clause
    const whereMatch = sql.match(/where\s+(.+?)(?:\s+order\s+by|\s+limit|$)/i);
    if (whereMatch) {
      results = this.applyWhere(results, whereMatch[1]);
    }
    
    // Parse ORDER BY clause
    const orderByMatch = sql.match(/order\s+by\s+([^limit]+)/i);
    if (orderByMatch) {
      results = this.applyOrderBy(results, orderByMatch[1]);
    }
    
    // Parse LIMIT clause
    const limitMatch = sql.match(/limit\s+(\d+)/i);
    if (limitMatch) {
      results = results.slice(0, parseInt(limitMatch[1]));
    }
    
    // Parse SELECT columns
    const selectMatch = sql.match(/select\s+(.+?)\s+from/i);
    if (selectMatch && selectMatch[1].trim() !== '*') {
      const columns = selectMatch[1].split(',').map(col => col.trim().replace(/['"]/g, ''));
      results = results.map(row => {
        const newRow: any = {};
        columns.forEach(col => {
          if (row.hasOwnProperty(col as keyof Customer)) {
            newRow[col] = row[col as keyof Customer];
          }
        });
        return newRow;
      });
    }
    
    return results;
  }

  private applyWhere(data: any[], whereClause: string): any[] {
    // Simple WHERE clause parsing (supports basic conditions)
    const conditions = whereClause.split(/\s+and\s+/i);
    
    return data.filter(row => {
      return conditions.every(condition => {
        const match = condition.match(/(\w+)\s*([><=!]+|like)\s*(.+)/i);
        if (!match) return true;
        
        const [, field, operator, valueStr] = match;
        const value = valueStr.replace(/['"]/g, '').trim();
        const rowValue = row[field];
        
        switch (operator.toLowerCase()) {
          case '=':
            return String(rowValue).toLowerCase() === value.toLowerCase();
          case '!=':
          case '<>':
            return String(rowValue).toLowerCase() !== value.toLowerCase();
          case '>':
            return Number(rowValue) > Number(value);
          case '<':
            return Number(rowValue) < Number(value);
          case '>=':
            return Number(rowValue) >= Number(value);
          case '<=':
            return Number(rowValue) <= Number(value);
          case 'like':
            const pattern = value.replace(/%/g, '.*');
            return new RegExp(pattern, 'i').test(String(rowValue));
          default:
            return true;
        }
      });
    });
  }

  private applyOrderBy(data: any[], orderClause: string): any[] {
    const [field, direction = 'asc'] = orderClause.trim().split(/\s+/);
    
    return data.sort((a, b) => {
      let aVal = a[field];
      let bVal = b[field];
      
      // Handle different data types
      if (typeof aVal === 'string') {
        aVal = aVal.toLowerCase();
        bVal = bVal.toLowerCase();
      }
      
      if (aVal < bVal) return direction.toLowerCase() === 'desc' ? 1 : -1;
      if (aVal > bVal) return direction.toLowerCase() === 'desc' ? -1 : 1;
      return 0;
    });
  }
}

// Natural Language to SQL converter
export class NLToSQL {
  private patterns = [
    {
      pattern: /show\s+(?:me\s+)?(?:all\s+)?customers?/i,
      sql: () => "SELECT * FROM customers"
    },
    {
      pattern: /(?:find|get|show)\s+(?:me\s+)?customers?\s+(?:in|from)\s+(.+)/i,
      sql: (match: RegExpMatchArray) => `SELECT * FROM customers WHERE city LIKE '%${match[1].trim()}%' OR country LIKE '%${match[1].trim()}%'`
    },
    {
      pattern: /(?:find|get|show)\s+(?:me\s+)?customers?\s+(?:with|having)\s+(.+)\s+purchases?/i,
      sql: (match: RegExpMatchArray) => {
        const amount = match[1].toLowerCase();
        if (amount.includes('more than') || amount.includes('over') || amount.includes('>')) {
          const num = match[1].match(/\d+/)?.[0] || '1000';
          return `SELECT * FROM customers WHERE total_purchases > ${num}`;
        } else if (amount.includes('less than') || amount.includes('under') || amount.includes('<')) {
          const num = match[1].match(/\d+/)?.[0] || '1000';
          return `SELECT * FROM customers WHERE total_purchases < ${num}`;
        }
        return "SELECT * FROM customers WHERE total_purchases > 1000";
      }
    },
    {
      pattern: /(?:find|get|show)\s+(?:me\s+)?(?:all\s+)?(\w+)\s+customers?/i,
      sql: (match: RegExpMatchArray) => `SELECT * FROM customers WHERE loyalty_level = '${match[1].charAt(0).toUpperCase() + match[1].slice(1).toLowerCase()}'`
    },
    {
      pattern: /(?:find|get|show)\s+(?:me\s+)?customers?\s+older\s+than\s+(\d+)/i,
      sql: (match: RegExpMatchArray) => `SELECT * FROM customers WHERE age > ${match[1]}`
    },
    {
      pattern: /(?:find|get|show)\s+(?:me\s+)?customers?\s+younger\s+than\s+(\d+)/i,
      sql: (match: RegExpMatchArray) => `SELECT * FROM customers WHERE age < ${match[1]}`
    },
    {
      pattern: /(?:count|how\s+many)\s+customers?/i,
      sql: () => "SELECT COUNT(*) as total_customers FROM customers"
    },
    {
      pattern: /average\s+age|avg\s+age/i,
      sql: () => "SELECT AVG(age) as average_age FROM customers"
    },
    {
      pattern: /top\s+(\d+)\s+customers?\s+by\s+purchases?/i,
      sql: (match: RegExpMatchArray) => `SELECT * FROM customers ORDER BY total_purchases DESC LIMIT ${match[1]}`
    },
    {
      pattern: /customers?\s+who\s+(?:haven't|have\s+not)\s+purchased?\s+recently/i,
      sql: () => "SELECT * FROM customers WHERE last_purchase_date < '2024-01-01' OR last_purchase_date IS NULL"
    }
  ];

  convert(naturalLanguage: string): string {
    const input = naturalLanguage.trim();
    
    for (const { pattern, sql } of this.patterns) {
      const match = input.match(pattern);
      if (match) {
        return typeof sql === 'function' ? sql(match) : sql();
      }
    }
    
    // Default fallback
    return "SELECT * FROM customers LIMIT 10";
  }
}

const sqlExecutor = new SQLExecutor();
const nlToSQL = new NLToSQL();

export async function initializeDatabase(): Promise<void> {
  // Simulate async database initialization
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log('Database initialized with sample data');
      resolve();
    }, 1000);
  });
}

export async function executeNLQuery(naturalLanguage: string): Promise<{
  sqlQuery: string;
  data: any[];
  columns: string[];
  error?: string;
}> {
  try {
    const sqlQuery = nlToSQL.convert(naturalLanguage);
    const data = sqlExecutor.execute(sqlQuery);
    
    // Extract columns from the first row
    const columns = data.length > 0 ? Object.keys(data[0]) : [];
    
    return {
      sqlQuery,
      data,
      columns
    };
  } catch (error) {
    return {
      sqlQuery: '',
      data: [],
      columns: [],
      error: error instanceof Error ? error.message : 'An error occurred'
    };
  }
}

export function getDatabaseStats() {
  const totalCustomers = customers.length;
  const avgAge = customers.reduce((sum, c) => sum + c.age, 0) / totalCustomers;
  const totalRevenue = customers.reduce((sum, c) => sum + c.total_purchases, 0);
  
  const loyaltyDistribution = customers.reduce((acc, c) => {
    acc[c.loyalty_level] = (acc[c.loyalty_level] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  const countryDistribution = customers.reduce((acc, c) => {
    acc[c.country] = (acc[c.country] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  return {
    totalCustomers,
    averageAge: Math.round(avgAge * 10) / 10,
    totalRevenue: Math.round(totalRevenue * 100) / 100,
    loyaltyDistribution,
    countryDistribution,
    recentPurchases: customers.filter(c => 
      c.last_purchase_date && new Date(c.last_purchase_date) > new Date('2024-01-01')
    ).length
  };
}
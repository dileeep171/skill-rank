import React, { useState, useEffect } from 'react';
import { Search, Database, BarChart3, Users, TrendingUp, Activity, Brain, History } from 'lucide-react';
import QueryInput from './components/QueryInput';
import ResultsDisplay from './components/ResultsDisplay';
import SampleQueries from './components/SampleQueries';
import QueryHistory from './components/QueryHistory';
import DatabaseStats from './components/DatabaseStats';
import { initializeDatabase, executeNLQuery } from './services/database';
import { QueryResult, QueryHistoryItem } from './types/database';

function App() {
  const [currentQuery, setCurrentQuery] = useState('');
  const [results, setResults] = useState<QueryResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [queryHistory, setQueryHistory] = useState<QueryHistoryItem[]>([]);
  const [activeTab, setActiveTab] = useState<'query' | 'history' | 'stats'>('query');
  const [dbInitialized, setDbInitialized] = useState(false);

  useEffect(() => {
    const initDB = async () => {
      try {
        await initializeDatabase();
        setDbInitialized(true);
      } catch (error) {
        console.error('Failed to initialize database:', error);
      }
    };
    initDB();
  }, []);

  const handleQuerySubmit = async (nlQuery: string) => {
    if (!nlQuery.trim()) return;

    setLoading(true);
    setCurrentQuery(nlQuery);

    try {
      const result = await executeNLQuery(nlQuery);
      setResults(result);
      
      // Add to history
      const historyItem: QueryHistoryItem = {
        id: Date.now().toString(),
        naturalLanguage: nlQuery,
        sqlQuery: result.sqlQuery,
        timestamp: new Date(),
        resultCount: result.data.length
      };
      setQueryHistory(prev => [historyItem, ...prev.slice(0, 9)]); // Keep last 10 queries
    } catch (error) {
      console.error('Query execution failed:', error);
      setResults({
        sqlQuery: '',
        data: [],
        columns: [],
        error: error instanceof Error ? error.message : 'Query execution failed'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleHistoryItemClick = (item: QueryHistoryItem) => {
    setCurrentQuery(item.naturalLanguage);
    handleQuerySubmit(item.naturalLanguage);
    setActiveTab('query');
  };

  if (!dbInitialized) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <Activity className="w-8 h-8 text-blue-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Initializing database...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Natural Language to SQL</h1>
                <p className="text-sm text-gray-500">Query your data with plain English</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Database className="w-4 h-4" />
                <span>Customer Database</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <nav className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <div className="space-y-2">
                <button
                  onClick={() => setActiveTab('query')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    activeTab === 'query'
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <Search className="w-4 h-4" />
                  <span>Query Builder</span>
                </button>
                <button
                  onClick={() => setActiveTab('history')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    activeTab === 'history'
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <History className="w-4 h-4" />
                  <span>Query History</span>
                  {queryHistory.length > 0 && (
                    <span className="bg-blue-600 text-white text-xs px-2 py-1 rounded-full ml-auto">
                      {queryHistory.length}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => setActiveTab('stats')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    activeTab === 'stats'
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <BarChart3 className="w-4 h-4" />
                  <span>Database Stats</span>
                </button>
              </div>
            </nav>

            {activeTab === 'query' && <SampleQueries onQuerySelect={handleQuerySubmit} />}
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === 'query' && (
              <div className="space-y-6">
                <QueryInput
                  onSubmit={handleQuerySubmit}
                  loading={loading}
                  currentQuery={currentQuery}
                />
                {results && (
                  <ResultsDisplay
                    results={results}
                    loading={loading}
                    naturalLanguageQuery={currentQuery}
                  />
                )}
              </div>
            )}

            {activeTab === 'history' && (
              <QueryHistory
                history={queryHistory}
                onQuerySelect={handleHistoryItemClick}
              />
            )}

            {activeTab === 'stats' && <DatabaseStats />}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;